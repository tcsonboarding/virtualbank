package com.example.demo.Model;

public class ExternalizedEnums {

	public enum AccountType{
		CHECKING, SAVINGS;
	}
}
